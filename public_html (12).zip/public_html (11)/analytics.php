<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - 3D Glassmorphism Dashboard</title>
    <meta name="description" content="3D Glassmorphism Dashboard Template by TemplateMo">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="templatemo-glass-admin-style.css">
    <!--

TemplateMo 607 Glass Admin

https://templatemo.com/tm-607-glass-admin

-->
</head>
<body>
    <!-- Animated Background -->
    <div class="background"></div>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>

    <div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">G</div>
                <span class="logo-text">GlassDash</span>
            </div>

            <ul class="nav-menu">
                <li class="nav-section">
                    <span class="nav-section-title">Main Menu</span>
                    <ul>
                        <li class="nav-item">
                            <a href="index.php" class="nav-link">
                                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
                                    <rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>
                                </svg>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="analytics.php" class="nav-link active">
                                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>
                                </svg>
                                Analytics
                                <span class="nav-badge">New</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="users.php" class="nav-link">
                                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
                                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                                </svg>
                                Users
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="settings.php" class="nav-link">
                                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="3"/>
                                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
                                </svg>
                                Settings
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-section">
                    <span class="nav-section-title">Account</span>
                    <ul>
                        <li class="nav-item">
                            <a href="login.php" class="nav-link">
                                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                                    <polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
                                </svg>
                                Logout
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>

            <div class="sidebar-footer">
                <div class="user-profile">
                    <div class="user-avatar">TM</div>
                    <div class="user-info">
                        <div class="user-name">TemplateMo</div>
                        <div class="user-role">Administrator</div>
                    </div>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="6 9 12 15 18 9"/>
                    </svg>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Navbar -->
            <nav class="navbar">
                <div class="page-header">
                    <h1 class="page-title">Analytics</h1>
                    <div class="page-breadcrumb">
                        <a href="index.php">Dashboard</a>
                        <span>/</span>
                        <span>Analytics</span>
                    </div>
                </div>
                <div class="navbar-right">
                    <div class="search-box">
                        <svg class="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                        <input type="text" class="search-input" placeholder="Search anything...">
                    </div>
                    <button class="nav-btn">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>
                        </svg>
                        <span class="notification-dot"></span>
                    </button>
                    <button class="nav-btn" id="theme-toggle" title="Toggle Light/Dark Mode">
                        <svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/>
                            <path d="M4.93 4.93l1.41 1.41"/><path d="M17.66 17.66l1.41 1.41"/>
                            <path d="M2 12h2"/><path d="M20 12h2"/>
                            <path d="M6.34 17.66l-1.41 1.41"/><path d="M19.07 4.93l-1.41 1.41"/>
                        </svg>
                        <svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: none;">
                            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
                        </svg>
                    </button>
                </div>
            </nav>

            <!-- Stats Cards -->
            <section class="stats-grid">
                <div class="glass-card glass-card-3d stat-card">
                    <div class="stat-card-inner">
                        <div class="stat-info">
                            <h3>Page Views</h3>
                            <div class="stat-value">1,284,521</div>
                            <span class="stat-change positive">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/></svg>
                                +24.5%
                            </span>
                        </div>
                        <div class="stat-icon cyan">
                            <svg viewBox="0 0 24 24" fill="none" stroke="var(--emerald-light)" stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
                            </svg>
                        </div>
                    </div>
                </div>

                <div class="glass-card glass-card-3d stat-card">
                    <div class="stat-card-inner">
                        <div class="stat-info">
                            <h3>Unique Visitors</h3>
                            <div class="stat-value">452,892</div>
                            <span class="stat-change positive">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/></svg>
                                +18.3%
                            </span>
                        </div>
                        <div class="stat-icon magenta">
                            <svg viewBox="0 0 24 24" fill="none" stroke="var(--gold)" stroke-width="2">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
                            </svg>
                        </div>
                    </div>
                </div>

                <div class="glass-card glass-card-3d stat-card">
                    <div class="stat-card-inner">
                        <div class="stat-info">
                            <h3>Bounce Rate</h3>
                            <div class="stat-value">32.8%</div>
                            <span class="stat-change negative">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/></svg>
                                +5.2%
                            </span>
                        </div>
                        <div class="stat-icon purple">
                            <svg viewBox="0 0 24 24" fill="none" stroke="var(--coral)" stroke-width="2">
                                <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>
                            </svg>
                        </div>
                    </div>
                </div>

                <div class="glass-card glass-card-3d stat-card">
                    <div class="stat-card-inner">
                        <div class="stat-info">
                            <h3>Avg. Session</h3>
                            <div class="stat-value">4:32</div>
                            <span class="stat-change positive">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/></svg>
                                +12.1%
                            </span>
                        </div>
                        <div class="stat-icon success">
                            <svg viewBox="0 0 24 24" fill="none" stroke="var(--success)" stroke-width="2">
                                <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
                            </svg>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Content Grid -->
            <section class="content-grid">
                <!-- Main Chart -->
                <div class="glass-card chart-card">
                    <div class="card-header">
                        <div>
                            <h2 class="card-title">Traffic Overview</h2>
                            <p class="card-subtitle">Daily visitors and page views</p>
                        </div>
                        <div class="card-actions">
                            <button class="card-btn">7 Days</button>
                            <button class="card-btn active">30 Days</button>
                            <button class="card-btn">90 Days</button>
                        </div>
                    </div>
                    <div class="chart-wrapper">
                        <div class="chart-container">
                            <div class="chart-y-axis">
                                <span class="y-value">50K</span>
                                <span class="y-value">40K</span>
                                <span class="y-value">30K</span>
                                <span class="y-value">20K</span>
                                <span class="y-value">10K</span>
                                <span class="y-value">0</span>
                            </div>
                            <div class="chart-placeholder">
                                <div class="chart-bar-group"><div class="chart-bar bar-emerald" style="height: 80px;"></div><span class="chart-label">1</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-emerald" style="height: 95px;"></div><span class="chart-label">2</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-emerald" style="height: 70px;"></div><span class="chart-label">3</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-emerald" style="height: 110px;"></div><span class="chart-label">4</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-emerald" style="height: 130px;"></div><span class="chart-label">5</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-gold" style="height: 145px;"></div><span class="chart-label">6</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-gold" style="height: 120px;"></div><span class="chart-label">7</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-gold" style="height: 100px;"></div><span class="chart-label">8</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-gold" style="height: 135px;"></div><span class="chart-label">9</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-gold" style="height: 155px;"></div><span class="chart-label">10</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-coral" style="height: 140px;"></div><span class="chart-label">11</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-coral" style="height: 125px;"></div><span class="chart-label">12</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-coral" style="height: 160px;"></div><span class="chart-label">13</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-coral" style="height: 175px;"></div><span class="chart-label">14</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-coral" style="height: 150px;"></div><span class="chart-label">15</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-teal" style="height: 165px;"></div><span class="chart-label">16</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-teal" style="height: 145px;"></div><span class="chart-label">17</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-teal" style="height: 130px;"></div><span class="chart-label">18</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-teal" style="height: 155px;"></div><span class="chart-label">19</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-teal" style="height: 180px;"></div><span class="chart-label">20</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-amber" style="height: 170px;"></div><span class="chart-label">21</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-amber" style="height: 160px;"></div><span class="chart-label">22</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-amber" style="height: 185px;"></div><span class="chart-label">23</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-amber" style="height: 175px;"></div><span class="chart-label">24</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-amber" style="height: 165px;"></div><span class="chart-label">25</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-emerald" style="height: 190px;"></div><span class="chart-label">26</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-emerald" style="height: 175px;"></div><span class="chart-label">27</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-emerald" style="height: 195px;"></div><span class="chart-label">28</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-emerald" style="height: 185px;"></div><span class="chart-label">29</span></div>
                                <div class="chart-bar-group"><div class="chart-bar bar-emerald" style="height: 200px;"></div><span class="chart-label">30</span></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Top Pages -->
                <div class="glass-card activity-card">
                    <div class="card-header">
                        <div>
                            <h2 class="card-title">Top Pages</h2>
                            <p class="card-subtitle">Most visited pages</p>
                        </div>
                    </div>
                    <div class="activity-list">
                        <div class="activity-item">
                            <div class="activity-avatar" style="background: linear-gradient(135deg, var(--emerald-light), var(--emerald));">1</div>
                            <div class="activity-content">
                                <p class="activity-text"><strong>/dashboard</strong></p>
                                <span class="activity-time">45,234 views</span>
                            </div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-avatar" style="background: linear-gradient(135deg, var(--gold), var(--amber));">2</div>
                            <div class="activity-content">
                                <p class="activity-text"><strong>/products</strong></p>
                                <span class="activity-time">32,891 views</span>
                            </div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-avatar" style="background: linear-gradient(135deg, var(--coral), var(--gold));">3</div>
                            <div class="activity-content">
                                <p class="activity-text"><strong>/pricing</strong></p>
                                <span class="activity-time">28,456 views</span>
                            </div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-avatar" style="background: linear-gradient(135deg, var(--success), var(--emerald));">4</div>
                            <div class="activity-content">
                                <p class="activity-text"><strong>/about</strong></p>
                                <span class="activity-time">19,234 views</span>
                            </div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-avatar" style="background: linear-gradient(135deg, var(--warning), var(--gold));">5</div>
                            <div class="activity-content">
                                <p class="activity-text"><strong>/contact</strong></p>
                                <span class="activity-time">12,567 views</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Bottom Grid -->
            <section class="bottom-grid">
                <!-- Device Breakdown -->
                <div class="glass-card">
                    <div class="card-header">
                        <div>
                            <h2 class="card-title">Devices</h2>
                            <p class="card-subtitle">Traffic by device type</p>
                        </div>
                    </div>
                    <div class="donut-container">
                        <div class="donut-chart">
                            <svg width="140" height="140" viewBox="0 0 140 140">
                                <circle class="donut-bg" cx="70" cy="70" r="54"/>
                                <circle class="donut-segment" cx="70" cy="70" r="54" stroke="var(--emerald-light)" stroke-dasharray="186.6 339.3" stroke-dashoffset="0"/>
                                <circle class="donut-segment" cx="70" cy="70" r="54" stroke="var(--gold)" stroke-dasharray="118.8 339.3" stroke-dashoffset="-186.6"/>
                                <circle class="donut-segment" cx="70" cy="70" r="54" stroke="var(--coral)" stroke-dasharray="33.9 339.3" stroke-dashoffset="-305.4"/>
                            </svg>
                            <div class="donut-center">
                                <div class="donut-value">100%</div>
                                <div class="donut-label">Total</div>
                            </div>
                        </div>
                        <div class="donut-legend">
                            <div class="legend-item"><span class="legend-color cyan"></span><span>Mobile (55%)</span></div>
                            <div class="legend-item"><span class="legend-color magenta"></span><span>Desktop (35%)</span></div>
                            <div class="legend-item"><span class="legend-color purple"></span><span>Tablet (10%)</span></div>
                        </div>
                    </div>
                </div>

                <!-- Browser Stats -->
                <div class="glass-card progress-card">
                    <div class="card-header">
                        <div>
                            <h2 class="card-title">Browsers</h2>
                            <p class="card-subtitle">Traffic by browser</p>
                        </div>
                    </div>
                    <div class="progress-item">
                        <div class="progress-header"><span class="progress-label">Chrome</span><span class="progress-value">64%</span></div>
                        <div class="progress-bar"><div class="progress-fill cyan" style="width: 64%;"></div></div>
                    </div>
                    <div class="progress-item">
                        <div class="progress-header"><span class="progress-label">Safari</span><span class="progress-value">22%</span></div>
                        <div class="progress-bar"><div class="progress-fill magenta" style="width: 22%;"></div></div>
                    </div>
                    <div class="progress-item">
                        <div class="progress-header"><span class="progress-label">Firefox</span><span class="progress-value">8%</span></div>
                        <div class="progress-bar"><div class="progress-fill purple" style="width: 8%;"></div></div>
                    </div>
                    <div class="progress-item">
                        <div class="progress-header"><span class="progress-label">Edge</span><span class="progress-value">6%</span></div>
                        <div class="progress-bar"><div class="progress-fill cyan" style="width: 6%;"></div></div>
                    </div>
                </div>

                <!-- Countries -->
                <div class="glass-card progress-card">
                    <div class="card-header">
                        <div>
                            <h2 class="card-title">Countries</h2>
                            <p class="card-subtitle">Top traffic sources</p>
                        </div>
                    </div>
                    <div class="progress-item">
                        <div class="progress-header"><span class="progress-label">🇺🇸 United States</span><span class="progress-value">38%</span></div>
                        <div class="progress-bar"><div class="progress-fill cyan" style="width: 38%;"></div></div>
                    </div>
                    <div class="progress-item">
                        <div class="progress-header"><span class="progress-label">🇬🇧 United Kingdom</span><span class="progress-value">18%</span></div>
                        <div class="progress-bar"><div class="progress-fill magenta" style="width: 18%;"></div></div>
                    </div>
                    <div class="progress-item">
                        <div class="progress-header"><span class="progress-label">🇩🇪 Germany</span><span class="progress-value">12%</span></div>
                        <div class="progress-bar"><div class="progress-fill purple" style="width: 12%;"></div></div>
                    </div>
                    <div class="progress-item">
                        <div class="progress-header"><span class="progress-label">🇨🇦 Canada</span><span class="progress-value">9%</span></div>
                        <div class="progress-bar"><div class="progress-fill cyan" style="width: 9%;"></div></div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <!-- Mobile Menu Toggle -->
    <button class="mobile-menu-toggle">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>
        </svg>
    </button>

    <!-- Footer -->
    <footer class="site-footer">
        <p>Copyright © 2026 Your Company. Designed by <a href="https://templatemo.com" target="_blank" rel="nofollow">TemplateMo</a></p>
    </footer>

    <script src="templatemo-glass-admin-script.js"></script>
    <!-- TemplateMo 607 Glass Admin -->
</body>
</html>