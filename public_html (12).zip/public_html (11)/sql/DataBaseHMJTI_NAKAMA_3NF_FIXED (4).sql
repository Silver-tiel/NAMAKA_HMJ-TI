-- ============================================================
-- DATABASE HMJTI NAKAMA — v2
-- Data dummy diganti dengan pengurus nyata periode 2025/2026
-- Analisis login: v_login TIDAK memiliki kolom email,
--   pastikan Auth.php login via username, bukan email.
--   Solusi login-via-email → tambah kolom email ke v_login (lihat bagian VIEW).
-- ============================================================

CREATE DATABASE IF NOT EXISTS DataBaseHMJTI_NAKAMA
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE DataBaseHMJTI_NAKAMA;


-- ============================================================
-- A. REFERENSI
-- ============================================================

CREATE TABLE divisi (
  id_divisi   INT          NOT NULL AUTO_INCREMENT,
  nama_divisi VARCHAR(100) NOT NULL,
  PRIMARY KEY (id_divisi)
);

-- jabatan.id_divisi → divisi.id_divisi (nullable: jabatan lintas-divisi)
-- jabatan.role_level digunakan v_login untuk derive role tanpa string matching
CREATE TABLE jabatan (
  id_jabatan   INT          NOT NULL AUTO_INCREMENT,
  nama_jabatan VARCHAR(100) NOT NULL,
  id_divisi    INT              NULL,
  role_level   VARCHAR(20)      NULL,
  PRIMARY KEY (id_jabatan),
  CONSTRAINT fk_jabatan_divisi FOREIGN KEY (id_divisi) REFERENCES divisi (id_divisi)
);

CREATE TABLE kode_pos (
  kode_pos       VARCHAR(5)   NOT NULL,
  provinsi       VARCHAR(100) NOT NULL,
  kota_kabupaten VARCHAR(100) NOT NULL,
  kecamatan      VARCHAR(100) NOT NULL,
  kelurahan      VARCHAR(100) NOT NULL,
  PRIMARY KEY (kode_pos)
);

-- ============================================================
-- B. ANGGOTA & KEPENGURUSAN
-- ============================================================

CREATE TABLE anggota (
  id_anggota         INT          NOT NULL AUTO_INCREMENT,
  kode_pos           VARCHAR(5)   NOT NULL,
  nim                VARCHAR(20)  NOT NULL UNIQUE,
  nama_lengkap       VARCHAR(150) NOT NULL,
  email              VARCHAR(100)     NULL,
  no_telp            VARCHAR(20)      NULL,
  angkatan           VARCHAR(10)      NULL,
  jurusan            VARCHAR(100)     NULL,
  program_studi      VARCHAR(100)     NULL,
  status_keanggotaan VARCHAR(50)  NOT NULL DEFAULT 'Aktif',
  PRIMARY KEY (id_anggota),
  CONSTRAINT fk_anggota_kode_pos FOREIGN KEY (kode_pos) REFERENCES kode_pos (kode_pos)
);

CREATE TABLE periode (
  id_periode    INT  NOT NULL AUTO_INCREMENT,
  tahun_mulai   YEAR NOT NULL,
  tahun_selesai YEAR NOT NULL,
  keterangan    TEXT     NULL,
  PRIMARY KEY (id_periode)
);

CREATE TABLE anggota_periode (
  id_anggota_periode INT NOT NULL AUTO_INCREMENT,
  id_anggota         INT NOT NULL,
  id_periode         INT NOT NULL,
  id_jabatan         INT NOT NULL,
  PRIMARY KEY (id_anggota_periode),
  UNIQUE KEY uq_anggota_periode (id_anggota, id_periode),
  CONSTRAINT fk_ap_anggota FOREIGN KEY (id_anggota) REFERENCES anggota (id_anggota),
  CONSTRAINT fk_ap_periode FOREIGN KEY (id_periode) REFERENCES periode  (id_periode),
  CONSTRAINT fk_ap_jabatan FOREIGN KEY (id_jabatan) REFERENCES jabatan  (id_jabatan)
);

-- role tidak disimpan, derive dari jabatan.role_level via JOIN di v_login
CREATE TABLE `password` (
  id_password INT          NOT NULL AUTO_INCREMENT,
  id_anggota  INT          NOT NULL UNIQUE,
  username    VARCHAR(50)  NOT NULL UNIQUE,
  `password`  VARCHAR(255) NOT NULL,
  PRIMARY KEY (id_password),
  CONSTRAINT fk_password_anggota FOREIGN KEY (id_anggota) REFERENCES anggota (id_anggota)
);


-- ============================================================
-- C. SESI & AUDIT
-- ============================================================

CREATE TABLE sesi_login (
  id_sesi     INT          NOT NULL AUTO_INCREMENT,
  id_anggota  INT          NOT NULL,
  token       VARCHAR(255) NOT NULL UNIQUE,
  ip_address  VARCHAR(45)      NULL,
  user_agent  VARCHAR(255)     NULL,
  login_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at  DATETIME     NOT NULL,
  logout_at   DATETIME         NULL,
  PRIMARY KEY (id_sesi),
  CONSTRAINT fk_sesi_anggota FOREIGN KEY (id_anggota) REFERENCES anggota (id_anggota)
);

CREATE TABLE log_aktivitas (
  id_log       INT          NOT NULL AUTO_INCREMENT,
  id_anggota   INT          NOT NULL,
  aksi         ENUM('CREATE','UPDATE','DELETE') NOT NULL,
  tabel_target VARCHAR(50)  NOT NULL,
  id_target    INT          NOT NULL,
  keterangan   TEXT             NULL,
  created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_log),
  CONSTRAINT fk_log_anggota FOREIGN KEY (id_anggota) REFERENCES anggota (id_anggota)
);


-- ============================================================
-- D. KEGIATAN
-- ============================================================

CREATE TABLE kegiatan (
  id_kegiatan      INT          NOT NULL AUTO_INCREMENT,
  id_anggota       INT          NOT NULL,
  judul            VARCHAR(200) NOT NULL,
  deskripsi        TEXT             NULL,
  penanggung_jawab VARCHAR(100)     NULL,
  tempat           VARCHAR(200)     NULL,
  waktu_mulai      DATETIME         NULL,
  waktu_selesai    DATETIME         NULL,
  created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id_kegiatan),
  CONSTRAINT fk_kegiatan_anggota FOREIGN KEY (id_anggota) REFERENCES anggota (id_anggota)
);

CREATE TABLE bukti_kegiatan (
  id_bukti      INT          NOT NULL AUTO_INCREMENT,
  id_kegiatan   INT          NOT NULL,
  file_bukti    VARCHAR(255) NOT NULL,
  keterangan    VARCHAR(255)     NULL,
  diunggah_pada DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_bukti),
  CONSTRAINT fk_bukti_kegiatan FOREIGN KEY (id_kegiatan) REFERENCES kegiatan (id_kegiatan) ON DELETE CASCADE
);

CREATE TABLE notifikasi (
  id_notifikasi INT          NOT NULL AUTO_INCREMENT,
  id_kegiatan   INT          NOT NULL,
  id_anggota    INT          NOT NULL,
  judul         VARCHAR(200) NOT NULL,
  pesan         TEXT             NULL,
  dibaca        TINYINT      NOT NULL DEFAULT 0,
  dibaca_pada   DATETIME         NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_notifikasi),
  CONSTRAINT fk_notif_kegiatan FOREIGN KEY (id_kegiatan) REFERENCES kegiatan (id_kegiatan),
  CONSTRAINT fk_notif_anggota  FOREIGN KEY (id_anggota)  REFERENCES anggota  (id_anggota)
);


-- ============================================================
-- E. KEUANGAN
-- ============================================================

CREATE TABLE kategori (
  id_kategori   INT          NOT NULL AUTO_INCREMENT,
  nama_kategori VARCHAR(100) NOT NULL,
  jenis         ENUM('Pemasukan Iuran','Pemasukan DIPA','Pemasukan Sponsorship','Pengeluaran') NOT NULL,
  PRIMARY KEY (id_kategori)
);

CREATE TABLE pemasukan (
  id_pemasukan     INT            NOT NULL AUTO_INCREMENT,
  id_anggota       INT            NOT NULL,
  id_kategori      INT            NOT NULL,
  id_kegiatan      INT                NULL,
  kode_pemasukan   VARCHAR(20)    NOT NULL UNIQUE,
  sumber_dana      VARCHAR(100)       NULL,
  jumlah           DECIMAL(15,2)  NOT NULL,
  tanggal          DATE           NOT NULL,
  bukti_pembayaran VARCHAR(255)       NULL,
  status           VARCHAR(20)    NOT NULL DEFAULT 'Menunggu',
  PRIMARY KEY (id_pemasukan),
  CONSTRAINT fk_pemasukan_anggota  FOREIGN KEY (id_anggota)  REFERENCES anggota  (id_anggota),
  CONSTRAINT fk_pemasukan_kategori FOREIGN KEY (id_kategori) REFERENCES kategori (id_kategori),
  CONSTRAINT fk_pemasukan_kegiatan FOREIGN KEY (id_kegiatan) REFERENCES kegiatan (id_kegiatan)
);

CREATE TABLE pengeluaran (
  id_pengeluaran   INT            NOT NULL AUTO_INCREMENT,
  id_anggota       INT            NOT NULL,
  id_kategori      INT            NOT NULL,
  id_kegiatan      INT                NULL,
  kode_pengeluaran VARCHAR(20)    NOT NULL UNIQUE,
  penerima         VARCHAR(100)       NULL,
  jumlah           DECIMAL(15,2)  NOT NULL,
  tanggal          DATE           NOT NULL,
  status           VARCHAR(20)    NOT NULL DEFAULT 'Menunggu',
  PRIMARY KEY (id_pengeluaran),
  CONSTRAINT fk_pengeluaran_anggota  FOREIGN KEY (id_anggota)  REFERENCES anggota  (id_anggota),
  CONSTRAINT fk_pengeluaran_kategori FOREIGN KEY (id_kategori) REFERENCES kategori (id_kategori),
  CONSTRAINT fk_pengeluaran_kegiatan FOREIGN KEY (id_kegiatan) REFERENCES kegiatan (id_kegiatan)
);

CREATE TABLE status_history_keuangan (
  id_history   INT                             NOT NULL AUTO_INCREMENT,
  tipe         ENUM('pemasukan','pengeluaran') NOT NULL,
  id_transaksi INT                             NOT NULL,
  id_anggota   INT                             NOT NULL,
  status_lama  VARCHAR(20)                         NULL,
  status_baru  VARCHAR(20)                     NOT NULL,
  created_at   DATETIME                        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  catatan      TEXT                                NULL,
  PRIMARY KEY (id_history),
  CONSTRAINT fk_shk_anggota FOREIGN KEY (id_anggota) REFERENCES anggota (id_anggota)
);


-- ============================================================
-- F. PEMINJAMAN RUANGAN
-- ============================================================

CREATE TABLE ruangan (
  id_ruangan   INT         NOT NULL AUTO_INCREMENT,
  kode_ruangan VARCHAR(10) NOT NULL UNIQUE,
  nama_ruangan VARCHAR(50) NOT NULL,
  kapasitas    INT             NULL DEFAULT 0,
  kursi        INT             NULL DEFAULT 0,
  meja         INT             NULL DEFAULT 0,
  ac           TINYINT         NULL DEFAULT 0,
  papan_tulis  TINYINT         NULL DEFAULT 0,
  proyektor    TINYINT         NULL DEFAULT 0,
  PRIMARY KEY (id_ruangan)
);

CREATE TABLE peminjam (
  id_peminjam   INT         NOT NULL AUTO_INCREMENT,
  kode_peminjam VARCHAR(10) NOT NULL UNIQUE,
  id_anggota    INT         NOT NULL,
  PRIMARY KEY (id_peminjam),
  CONSTRAINT fk_peminjam_anggota FOREIGN KEY (id_anggota) REFERENCES anggota (id_anggota)
);

CREATE TABLE peminjaman_ruangan (
  id_peminjaman     INT         NOT NULL AUTO_INCREMENT,
  kode_peminjaman   VARCHAR(10) NOT NULL UNIQUE,
  id_peminjam       INT         NOT NULL,
  tujuan_peminjaman VARCHAR(100)    NULL,
  surat_peminjaman  VARCHAR(255)    NULL,
  status            VARCHAR(20) NOT NULL DEFAULT 'Menunggu',
  created_at        DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id_peminjaman),
  CONSTRAINT fk_peminjaman_peminjam FOREIGN KEY (id_peminjam) REFERENCES peminjam (id_peminjam)
);

CREATE TABLE detail_peminjaman (
  id_detail     INT      NOT NULL AUTO_INCREMENT,
  id_peminjaman INT      NOT NULL,
  id_ruangan    INT      NOT NULL,
  waktu_mulai   DATETIME NOT NULL,
  waktu_selesai DATETIME NOT NULL,
  PRIMARY KEY (id_detail),
  CONSTRAINT fk_detail_peminjaman FOREIGN KEY (id_peminjaman) REFERENCES peminjaman_ruangan (id_peminjaman),
  CONSTRAINT fk_detail_ruangan    FOREIGN KEY (id_ruangan)    REFERENCES ruangan            (id_ruangan),
  CONSTRAINT chk_waktu            CHECK (waktu_selesai > waktu_mulai)
);

DELIMITER $$
CREATE TRIGGER trg_cek_konflik_jadwal
BEFORE INSERT ON detail_peminjaman
FOR EACH ROW
BEGIN
  DECLARE konflik INT DEFAULT 0;
  SELECT COUNT(*) INTO konflik
  FROM detail_peminjaman dp
    JOIN peminjaman_ruangan pr ON dp.id_peminjaman = pr.id_peminjaman
  WHERE dp.id_ruangan = NEW.id_ruangan
    AND pr.status NOT IN ('Ditolak', 'Selesai')
    AND dp.waktu_mulai  < NEW.waktu_selesai
    AND dp.waktu_selesai > NEW.waktu_mulai;
  IF konflik > 0 THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Konflik jadwal: ruangan sudah dipesan pada waktu tersebut';
  END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER trg_cek_konflik_jadwal_update
BEFORE UPDATE ON detail_peminjaman
FOR EACH ROW
BEGIN
  DECLARE konflik INT DEFAULT 0;
  SELECT COUNT(*) INTO konflik
  FROM detail_peminjaman dp
    JOIN peminjaman_ruangan pr ON dp.id_peminjaman = pr.id_peminjaman
  WHERE dp.id_ruangan     = NEW.id_ruangan
    AND dp.id_detail      != NEW.id_detail
    AND pr.status NOT IN ('Ditolak', 'Selesai')
    AND dp.waktu_mulai  < NEW.waktu_selesai
    AND dp.waktu_selesai > NEW.waktu_mulai;
  IF konflik > 0 THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Konflik jadwal: ruangan sudah dipesan pada waktu tersebut';
  END IF;
END$$
DELIMITER ;

CREATE TABLE status_history_ruangan (
  id_history        INT         NOT NULL AUTO_INCREMENT,
  id_peminjaman     INT         NOT NULL,
  id_anggota        INT         NOT NULL,
  status_lama       VARCHAR(20)     NULL,
  status_baru       VARCHAR(20) NOT NULL,
  tanggal_perubahan DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  catatan           TEXT            NULL,
  PRIMARY KEY (id_history),
  CONSTRAINT fk_shr_peminjaman FOREIGN KEY (id_peminjaman) REFERENCES peminjaman_ruangan (id_peminjaman),
  CONSTRAINT fk_shr_anggota    FOREIGN KEY (id_anggota)    REFERENCES anggota            (id_anggota)
);


-- ============================================================
-- G. SURAT
-- ============================================================

CREATE TABLE draft_surat (
  id_draft           INT          NOT NULL AUTO_INCREMENT,
  id_anggota         INT          NOT NULL,
  file               VARCHAR(255)     NULL,
  deskripsi_kegiatan TEXT             NULL,
  created_at         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_draft),
  CONSTRAINT fk_draft_anggota FOREIGN KEY (id_anggota) REFERENCES anggota (id_anggota)
);

CREATE TABLE surat (
  id_surat     INT          NOT NULL AUTO_INCREMENT,
  id_draft     INT          NOT NULL,
  nomor_surat  VARCHAR(50)      NULL UNIQUE COMMENT 'Format: 001/HMJ-TI/III/2026',
  file         VARCHAR(255)     NULL,
  PRIMARY KEY (id_surat),
  CONSTRAINT fk_surat_draft FOREIGN KEY (id_draft) REFERENCES draft_surat (id_draft)
);

CREATE TABLE pengajuan_surat (
  id_pengajuan   INT         NOT NULL AUTO_INCREMENT,
  id_surat       INT         NOT NULL,
  tanggal_unggah DATE        NOT NULL,
  tanggal_update DATE            NULL,
  status         VARCHAR(20) NOT NULL DEFAULT 'Menunggu',
  PRIMARY KEY (id_pengajuan),
  CONSTRAINT fk_pengajuan_surat FOREIGN KEY (id_surat) REFERENCES surat (id_surat)
);

CREATE TABLE status_history (
  id_history        INT         NOT NULL AUTO_INCREMENT,
  id_pengajuan      INT         NOT NULL,
  id_anggota        INT         NOT NULL,
  status_lama       VARCHAR(20)     NULL,
  status_baru       VARCHAR(20) NOT NULL,
  tanggal_perubahan DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  catatan           TEXT            NULL,
  PRIMARY KEY (id_history),
  CONSTRAINT fk_history_pengajuan FOREIGN KEY (id_pengajuan) REFERENCES pengajuan_surat (id_pengajuan),
  CONSTRAINT fk_history_anggota   FOREIGN KEY (id_anggota)   REFERENCES anggota         (id_anggota)
);


-- ============================================================
-- DATA AWAL (SEED) — REFERENSI TETAP
-- ============================================================

INSERT INTO divisi (id_divisi, nama_divisi) VALUES
  (1, 'BPH'),
  (2, 'Administrasi'),
  (3, 'Keilmuan'),
  (4, 'Perhubungan'),
  (5, 'Kominfo'),
  (6, 'KWU');

INSERT INTO jabatan (id_jabatan, nama_jabatan, id_divisi, role_level) VALUES
  (1,  'Ketua',                       NULL, 'ketua'),
  (2,  'Sekretaris',                  NULL, 'sekretaris'),
  (3,  'Bendahara',                   NULL, 'bendahara'),
  (4,  'Ketua Divisi BPH',            1,    'anggota'),
  (5,  'Ketua Divisi Administrasi',   2,    'anggota'),
  (6,  'Ketua Divisi Keilmuan',       3,    'anggota'),
  (7,  'Ketua Divisi Perhubungan',    4,    'anggota'),
  (8,  'Ketua Divisi Kominfo',        5,    'anggota'),
  (9,  'Ketua Divisi KWU',            6,    'anggota'),
  (10, 'Anggota Divisi BPH',          1,    'anggota'),
  (11, 'Anggota Divisi Administrasi', 2,    'anggota'),
  (12, 'Anggota Divisi Keilmuan',     3,    'anggota'),
  (13, 'Anggota Divisi Perhubungan',  4,    'anggota'),
  (14, 'Anggota Divisi Kominfo',      5,    'anggota'),
  (15, 'Anggota Divisi KWU',          6,    'anggota'),
  (16, 'Alumni',                      NULL, 'alumni');

INSERT INTO kode_pos (kode_pos, provinsi, kota_kabupaten, kecamatan, kelurahan) VALUES
  ('68121', 'Jawa Timur', 'Kabupaten Jember', 'Sumbersari', 'Sumbersari'),
  ('68122', 'Jawa Timur', 'Kabupaten Jember', 'Sumbersari', 'Kranjingan'),
  ('68123', 'Jawa Timur', 'Kabupaten Jember', 'Sumbersari', 'Wirolegi'),
  ('68124', 'Jawa Timur', 'Kabupaten Jember', 'Kaliwates',  'Kaliwates'),
  ('68125', 'Jawa Timur', 'Kabupaten Jember', 'Patrang',    'Patrang');


-- ============================================================
-- DATA ANGGOTA NYATA — PERIODE 2025/2026
-- ============================================================
-- Mapping jabatan berdasarkan input:
--   id_jabatan 1  = Ketua          → Irzal Amru Alqahtani & Aditya Bambang K.
--   id_jabatan 2  = Sekretaris     → Fajar Muharram & Devis Sapta Pratama
--   id_jabatan 3  = Bendahara      → Gabriel Putra S.H & M. Nanda Krisna Murti
--
-- Catatan: dua orang menjabat Ketua dan dua orang menjabat Bendahara.
--   Diasumsikan Irzal = Ketua Umum (role_level 'ketua'),
--               Aditya = Wakil Ketua → ditambahkan ke jabatan baru id 17.
--   Fajar & Devis keduanya Sekretaris (id_jabatan 2).
--   Gabriel = Bendahara I, Nanda = Bendahara II → Nanda pakai id 18.
--   Penyesuaian ini dicatat di INSERT jabatan di bawah.
-- ============================================================

-- Tambah jabatan baru untuk Wakil Ketua dan Bendahara II
INSERT INTO jabatan (id_jabatan, nama_jabatan, id_divisi, role_level) VALUES
  (17, 'Wakil Ketua', NULL, 'ketua'),
  (18, 'Bendahara II', NULL, 'bendahara');

-- ============================================================
-- ANGGOTA
-- id  NIM           Nama                       Jabatan
--  1  E41251558  Irzal Amru Alqahtani          Ketua
--  2  E41251215  Fajar Muharram                Sekretaris I
--  3  E41251276  Devis Sapta Pratama           Sekretaris II
--  4  E41251254  Gabriel Putra S.H             Bendahara I
--  5  E41251323  Aditya Bambang Kurniawan      Wakil Ketua
--  6  E41351410  Muhammad Nanda Krisna Murti   Bendahara II
-- ============================================================

INSERT INTO anggota (id_anggota, kode_pos, nim, nama_lengkap, email, no_telp, angkatan, jurusan, program_studi, status_keanggotaan) VALUES
  (1, '68121', 'E41251558', 'Irzal Amru Alqahtani',        'E41251558@student.polije.ac.id',   '081234000001', '2025', 'Teknologi Informasi', 'D4 Teknik Informatika', 'Aktif'),
  (2, '68122', 'E41251215', 'Fajar Muharram',               'E41251215@student.polije.ac.id',   '081234000002', '2025', 'Teknologi Informasi', 'D4 Teknik Informatika', 'Aktif'),
  (3, '68123', 'E41251276', 'Devis Sapta Pratama',          'E41251276@student.polije.ac.id',   '081234000003', '2025', 'Teknologi Informasi', 'D4 Teknik Informatika', 'Aktif'),
  (4, '68124', 'E41251254', 'Gabriel Putra S.H',            'E41251254@student.polije.ac.id', '081234000004', '2025', 'Teknologi Informasi', 'D4 Teknik Informatika', 'Aktif'),
  (5, '68125', 'E41251323', 'Aditya Bambang Kurniawan',     'E41251323@student.polije.ac.id',  '081234000005', '2025', 'Teknologi Informasi', 'D4 Teknik Informatika', 'Aktif'),
  (6, '68121', 'E41351310', 'Muhammad Nanda Krisna Murti',  'E41251310@student.polije.ac.id',   '081234000006', '2025', 'Teknologi Informasi', 'D4 Teknik Informatika', 'Aktif');

INSERT INTO periode (id_periode, tahun_mulai, tahun_selesai, keterangan) VALUES
  (1, 2024, 2025, 'Periode kepengurusan 2024/2025'),
  (2, 2025, 2026, 'Periode kepengurusan 2025/2026');

-- Semua anggota di periode 2 (2025/2026) sebagai periode aktif
INSERT INTO anggota_periode (id_anggota, id_periode, id_jabatan) VALUES
  (1, 2,  1),   -- Irzal      → Ketua
  (2, 2,  2),   -- Fajar      → Sekretaris
  (3, 2,  2),   -- Devis      → Sekretaris (uq_anggota_periode: satu baris per anggota per periode)
  (4, 2,  3),   -- Gabriel    → Bendahara
  (5, 2, 17),   -- Aditya     → Wakil Ketua
  (6, 2, 18);   -- Nanda      → Bendahara II

-- ============================================================
-- CATATAN PENTING — CONSTRAINT uq_anggota_periode
-- ============================================================
-- Tabel anggota_periode memiliki UNIQUE KEY (id_anggota, id_periode),
-- artinya satu anggota hanya boleh punya SATU jabatan per periode.
-- Fajar (id=2) dan Devis (id=3) keduanya berjabatan Sekretaris,
-- tetapi karena id_anggota berbeda, INSERT di atas VALID.
-- Tidak ada konflik constraint.
-- ============================================================

-- Password semua anggota (hash bcrypt — plaintext: "password123")
INSERT INTO `password` (id_anggota, username, `password`) VALUES
  (1, 'irzal.ketua',    '$2y$10$c/E4di3XU6183fL4N/svKuEA4dLMlglzQx9ZQrWAI7VbaBj7f15hS'),
  (2, 'fajar.sekret',   '$2y$10$c/E4di3XU6183fL4N/svKuEA4dLMlglzQx9ZQrWAI7VbaBj7f15hS'),
  (3, 'devis.sekret',   '$2y$10$c/E4di3XU6183fL4N/svKuEA4dLMlglzQx9ZQrWAI7VbaBj7f15hS'),
  (4, 'gabriel.bendah', '$2y$10$c/E4di3XU6183fL4N/svKuEA4dLMlglzQx9ZQrWAI7VbaBj7f15hS'),
  (5, 'aditya.wakil',   '$2y$10$c/E4di3XU6183fL4N/svKuEA4dLMlglzQx9ZQrWAI7VbaBj7f15hS'),
  (6, 'nanda.bendah',   '$2y$10$c/E4di3XU6183fL4N/svKuEA4dLMlglzQx9ZQrWAI7VbaBj7f15hS');

INSERT INTO kategori (nama_kategori, jenis) VALUES
  ('Iuran Anggota',    'Pemasukan Iuran'),
  ('Dana Kampus/DIPA', 'Pemasukan DIPA'),
  ('Sponsorship',      'Pemasukan Sponsorship'),
  ('Konsumsi',         'Pengeluaran'),
  ('Perlengkapan',     'Pengeluaran'),
  ('Transportasi',     'Pengeluaran'),
  ('Honorarium',       'Pengeluaran');


-- ============================================================
-- DATA DUMMY — KEGIATAN & TRANSAKSI
-- (Menggunakan id_anggota dari pengurus baru di atas)
-- ============================================================

-- Kegiatan — id_anggota = 1 (Irzal, Ketua) sebagai pembuat
INSERT INTO kegiatan (id_kegiatan, id_anggota, judul, deskripsi, penanggung_jawab, tempat, waktu_mulai, waktu_selesai) VALUES
  (1, 1, 'Seminar Teknologi AI 2026',       'Seminar perkembangan AI di dunia kerja',                    'Irzal Amru Alqahtani',       'Aula Polije Lantai 3',  '2026-09-15 08:00:00', '2026-09-15 16:00:00'),
  (2, 1, 'Rapat Koordinasi Bulanan',         'Rapat rutin evaluasi program kerja',                        'Fajar Muharram',              'Ruang 3.2',             '2026-10-01 09:00:00', '2026-10-01 12:00:00'),
  (3, 2, 'Lomba Karya Tulis Ilmiah 2026',    'Kompetisi KTI tingkat politeknik se-Jawa Timur',            'Aditya Bambang Kurniawan',    'Gedung A Polije',       '2026-11-10 08:00:00', '2026-11-10 17:00:00'),
  (4, 1, 'Pelatihan UI/UX Design',           'Workshop desain antarmuka untuk anggota divisi kominfo',    'Devis Sapta Pratama',         'Lab. Komputer 2',       '2026-11-20 09:00:00', '2026-11-20 15:00:00'),
  (5, 2, 'Musyawarah Anggota Tahunan',       'Evaluasi program kerja dan pemilihan pengurus baru',        'Irzal Amru Alqahtani',       'Aula Polije Lantai 3',  '2026-12-05 08:00:00', '2026-12-05 16:00:00');

-- Bukti kegiatan
INSERT INTO bukti_kegiatan (id_kegiatan, file_bukti, keterangan) VALUES
  (1, 'uploads/bukti/seminar_ai_foto1.jpg',   'Foto pembukaan seminar'),
  (1, 'uploads/bukti/seminar_ai_foto2.jpg',   'Foto sesi tanya jawab'),
  (2, 'uploads/bukti/rapat_okt_foto1.jpg',    'Foto rapat koordinasi Oktober'),
  (3, 'uploads/bukti/lkti_poster.jpg',        'Poster pengumuman LKTI'),
  (4, 'uploads/bukti/uiux_materi.pdf',        'Materi pelatihan UI/UX');

-- Notifikasi
INSERT INTO notifikasi (id_kegiatan, id_anggota, judul, pesan) VALUES
  (1, 2, 'Undangan Seminar AI',    'Hadir di Aula Polije 15 Sep 2026, pukul 08.00 WIB.'),
  (1, 3, 'Undangan Seminar AI',    'Hadir di Aula Polije 15 Sep 2026, pukul 08.00 WIB.'),
  (1, 4, 'Undangan Seminar AI',    'Hadir di Aula Polije 15 Sep 2026, pukul 08.00 WIB.'),
  (1, 5, 'Undangan Seminar AI',    'Hadir di Aula Polije 15 Sep 2026, pukul 08.00 WIB.'),
  (1, 6, 'Undangan Seminar AI',    'Hadir di Aula Polije 15 Sep 2026, pukul 08.00 WIB.'),
  (2, 2, 'Rapat Koordinasi',       'Rapat bulanan 1 Okt 2026, Ruang 3.2, pukul 09.00 WIB.'),
  (2, 3, 'Rapat Koordinasi',       'Rapat bulanan 1 Okt 2026, Ruang 3.2, pukul 09.00 WIB.'),
  (2, 4, 'Rapat Koordinasi',       'Rapat bulanan 1 Okt 2026, Ruang 3.2, pukul 09.00 WIB.'),
  (3, 5, 'Undangan LKTI 2026',     'Daftarkan tim kamu sebelum 5 Nov 2026.'),
  (3, 6, 'Undangan LKTI 2026',     'Daftarkan tim kamu sebelum 5 Nov 2026.'),
  (4, 3, 'Pelatihan UI/UX',        'Hadir di Lab. Komputer 2, 20 Nov 2026 pukul 09.00 WIB.'),
  (4, 5, 'Pelatihan UI/UX',        'Hadir di Lab. Komputer 2, 20 Nov 2026 pukul 09.00 WIB.'),
  (5, 2, 'Musyawarah Anggota',     'Kehadiran wajib, 5 Des 2026 pukul 08.00 WIB.'),
  (5, 3, 'Musyawarah Anggota',     'Kehadiran wajib, 5 Des 2026 pukul 08.00 WIB.'),
  (5, 4, 'Musyawarah Anggota',     'Kehadiran wajib, 5 Des 2026 pukul 08.00 WIB.'),
  (5, 5, 'Musyawarah Anggota',     'Kehadiran wajib, 5 Des 2026 pukul 08.00 WIB.'),
  (5, 6, 'Musyawarah Anggota',     'Kehadiran wajib, 5 Des 2026 pukul 08.00 WIB.');

-- Pemasukan — id_anggota = 4 atau 6 (Gabriel/Nanda, Bendahara)
INSERT INTO pemasukan (id_anggota, id_kategori, id_kegiatan, kode_pemasukan, sumber_dana, jumlah, tanggal, status) VALUES
  (4, 1, NULL, 'PMK-2026-001', 'Iuran anggota aktif',         500000.00, '2026-09-01', 'Disetujui'),
  (4, 2, 1,    'PMK-2026-002', 'Dana DIPA Polije',           2000000.00, '2026-09-05', 'Disetujui'),
  (4, 3, 1,    'PMK-2026-003', 'PT. Teknologi Nusantara',     750000.00, '2026-09-07', 'Menunggu'),
  (4, 1, NULL, 'PMK-2026-004', 'Iuran anggota aktif',         500000.00, '2026-10-01', 'Disetujui'),
  (6, 2, 3,    'PMK-2026-005', 'Dana DIPA Polije',           1500000.00, '2026-10-25', 'Disetujui'),
  (6, 3, 4,    'PMK-2026-006', 'CV. Kreatif Nusantara',       600000.00, '2026-11-05', 'Menunggu'),
  (6, 2, 5,    'PMK-2026-007', 'Dana DIPA Polije',            800000.00, '2026-11-20', 'Disetujui');

-- Pengeluaran — id_anggota = 4 atau 6 (Gabriel/Nanda, Bendahara)
INSERT INTO pengeluaran (id_anggota, id_kategori, id_kegiatan, kode_pengeluaran, penerima, jumlah, tanggal, status) VALUES
  (4, 4, 1, 'PKL-2026-001', 'Catering Bu Sari',    800000.00, '2026-09-15', 'Disetujui'),
  (4, 5, 1, 'PKL-2026-002', 'Toko ATK Jember',     250000.00, '2026-09-14', 'Disetujui'),
  (4, 6, 1, 'PKL-2026-003', 'Pool Angkutan Umum',  150000.00, '2026-09-15', 'Ditolak'),
  (6, 4, 3, 'PKL-2026-004', 'Catering Pak Haji',   600000.00, '2026-11-10', 'Disetujui'),
  (6, 5, 3, 'PKL-2026-005', 'Toko ATK Jember',     175000.00, '2026-11-08', 'Disetujui'),
  (6, 7, 4, 'PKL-2026-006', 'Instruktur UI/UX',    500000.00, '2026-11-20', 'Disetujui'),
  (6, 6, 4, 'PKL-2026-007', 'Pool Angkutan Umum',  100000.00, '2026-11-20', 'Menunggu'),
  (6, 4, 5, 'PKL-2026-008', 'Catering Bu Sari',    900000.00, '2026-12-05', 'Menunggu'),
  (6, 5, 5, 'PKL-2026-009', 'Toko ATK Jember',     120000.00, '2026-12-04', 'Disetujui');

-- Status history keuangan — id_anggota = 1 (Irzal, Ketua, yang menyetujui)
INSERT INTO status_history_keuangan (tipe, id_transaksi, id_anggota, status_lama, status_baru, catatan) VALUES
  ('pemasukan',   1, 1, 'Menunggu', 'Disetujui', 'Iuran September sudah diverifikasi'),
  ('pemasukan',   2, 1, 'Menunggu', 'Disetujui', 'Dana DIPA seminar sudah masuk'),
  ('pemasukan',   4, 1, 'Menunggu', 'Disetujui', 'Iuran Oktober sudah diverifikasi'),
  ('pemasukan',   5, 1, 'Menunggu', 'Disetujui', 'Dana DIPA LKTI sudah masuk'),
  ('pemasukan',   7, 1, 'Menunggu', 'Disetujui', 'Dana DIPA Musyawarah sudah masuk'),
  ('pengeluaran', 1, 1, 'Menunggu', 'Disetujui', 'Kwitansi catering diterima'),
  ('pengeluaran', 2, 1, 'Menunggu', 'Disetujui', 'Struk ATK diterima'),
  ('pengeluaran', 3, 1, 'Menunggu', 'Ditolak',   'Tidak ada bukti pembayaran transport'),
  ('pengeluaran', 4, 1, 'Menunggu', 'Disetujui', 'Kwitansi catering LKTI diterima'),
  ('pengeluaran', 5, 1, 'Menunggu', 'Disetujui', 'Struk ATK LKTI diterima'),
  ('pengeluaran', 6, 1, 'Menunggu', 'Disetujui', 'Honorarium instruktur UI/UX dibayar');

-- Ruangan (tidak berubah)
INSERT INTO ruangan (id_ruangan, kode_ruangan, nama_ruangan, kapasitas, kursi, meja, ac, papan_tulis, proyektor) VALUES
  (1, 'R-3-02', '3.2',            40,  40, 20, 1, 1, 1),
  (2, 'R-3-03', '3.3',            40,  40, 20, 1, 1, 1),
  (3, 'LAB-PL', 'Lab. PL',        30,  30, 30, 2, 1, 2),
  (4, 'LAB-JR', 'Lab. Jaringan',  30,  30, 30, 2, 1, 1),
  (5, 'AULA-1', 'Aula Lantai 3', 150, 150,  0, 4, 1, 3);

-- Peminjam — menggunakan anggota nyata
INSERT INTO peminjam (id_peminjam, kode_peminjam, id_anggota) VALUES
  (1, 'PJM-001', 3),   -- Devis
  (2, 'PJM-002', 5),   -- Aditya
  (3, 'PJM-003', 2),   -- Fajar
  (4, 'PJM-004', 6),   -- Nanda
  (5, 'PJM-005', 4);   -- Gabriel

INSERT INTO peminjaman_ruangan (id_peminjaman, kode_peminjaman, id_peminjam, tujuan_peminjaman, status) VALUES
  (1, 'PR-0001', 1, 'Rapat BPH',             'Disetujui'),
  (2, 'PR-0002', 2, 'Latihan Presentasi',    'Menunggu'),
  (3, 'PR-0003', 3, 'Persiapan LKTI 2026',  'Disetujui'),
  (4, 'PR-0004', 4, 'Rapat Keuangan',        'Ditolak'),
  (5, 'PR-0005', 5, 'Workshop Pemrograman',  'Menunggu');

INSERT INTO detail_peminjaman (id_detail, id_peminjaman, id_ruangan, waktu_mulai, waktu_selesai) VALUES
  (1, 1, 1, '2026-10-10 13:00:00', '2026-10-10 15:00:00'),
  (2, 2, 2, '2026-10-11 09:00:00', '2026-10-11 11:00:00'),
  (3, 3, 3, '2026-11-08 10:00:00', '2026-11-08 12:00:00'),
  (4, 4, 1, '2026-11-09 13:00:00', '2026-11-09 15:00:00'),
  (5, 5, 4, '2026-11-15 09:00:00', '2026-11-15 12:00:00');

-- Status history ruangan — id_anggota = 1 (Irzal, Ketua)
INSERT INTO status_history_ruangan (id_peminjaman, id_anggota, status_lama, status_baru, catatan) VALUES
  (1, 1, 'Menunggu', 'Disetujui', 'Disetujui oleh Ketua HMJ'),
  (3, 1, 'Menunggu', 'Disetujui', 'Disetujui untuk persiapan LKTI'),
  (4, 2, 'Menunggu', 'Ditolak',   'Ruangan sudah dipakai untuk ujian');

-- Draft surat — id_anggota = 2 atau 3 (Fajar/Devis, Sekretaris)
INSERT INTO draft_surat (id_anggota, file, deskripsi_kegiatan) VALUES
  (2, 'uploads/drafts/surat_seminar_ai.pdf',     'Surat permohonan izin tempat Seminar AI 2026'),
  (2, 'uploads/drafts/surat_rapat_bulanan.pdf',  'Surat undangan Rapat Koordinasi Bulanan Oktober'),
  (3, 'uploads/drafts/surat_lkti.pdf',           'Surat permohonan izin penyelenggaraan LKTI 2026'),
  (3, 'uploads/drafts/surat_pelatihan_uiux.pdf', 'Surat peminjaman lab untuk pelatihan UI/UX'),
  (2, 'uploads/drafts/surat_musyawarah.pdf',     'Surat undangan musyawarah anggota tahunan');

INSERT INTO surat (id_draft, nomor_surat, file) VALUES
  (1, '001/HMJ-TI/IX/2026',  'uploads/surat/surat_seminar_ai_final.pdf'),
  (2, '002/HMJ-TI/X/2026',   'uploads/surat/surat_rapat_bulanan_final.pdf'),
  (3, '003/HMJ-TI/X/2026',   'uploads/surat/surat_lkti_final.pdf'),
  (4, '004/HMJ-TI/XI/2026',  'uploads/surat/surat_pelatihan_uiux_final.pdf'),
  (5, NULL,                   'uploads/surat/surat_musyawarah_draft.pdf');

INSERT INTO pengajuan_surat (id_surat, tanggal_unggah, tanggal_update, status) VALUES
  (1, '2026-09-05', '2026-09-07', 'Selesai'),
  (2, '2026-09-28', '2026-09-30', 'Selesai'),
  (3, '2026-10-28', '2026-10-30', 'Selesai'),
  (4, '2026-11-12', '2026-11-13', 'Diproses'),
  (5, '2026-11-25', NULL,          'Menunggu');

INSERT INTO status_history (id_pengajuan, id_anggota, status_lama, status_baru, tanggal_perubahan, catatan) VALUES
  (1, 1, 'Menunggu', 'Diproses', '2026-09-06 09:00:00', 'Surat sudah diterima, sedang ditinjau'),
  (1, 1, 'Diproses', 'Selesai',  '2026-09-07 14:00:00', 'Disetujui oleh Ketua HMJ'),
  (2, 1, 'Menunggu', 'Diproses', '2026-09-29 10:00:00', 'Surat diterima, sedang ditinjau'),
  (2, 1, 'Diproses', 'Selesai',  '2026-09-30 14:00:00', 'Disetujui oleh Ketua HMJ'),
  (3, 2, 'Menunggu', 'Diproses', '2026-10-29 09:00:00', 'Surat permohonan LKTI sedang ditinjau'),
  (3, 1, 'Diproses', 'Selesai',  '2026-10-30 11:00:00', 'Disetujui oleh Ketua HMJ'),
  (4, 2, 'Menunggu', 'Diproses', '2026-11-13 08:30:00', 'Surat peminjaman lab sedang diproses');

-- Sesi login — data sample
INSERT INTO sesi_login (id_anggota, token, ip_address, user_agent, login_at, expires_at, logout_at) VALUES
  (1, 'tok_irzal_001abc',   '192.168.1.10', 'Mozilla/5.0 (Windows NT 10.0)', '2026-10-01 08:00:00', '2026-10-01 20:00:00', '2026-10-01 15:30:00'),
  (2, 'tok_fajar_002def',   '192.168.1.11', 'Mozilla/5.0 (Macintosh)',       '2026-10-01 08:15:00', '2026-10-01 20:15:00', '2026-10-01 14:00:00'),
  (3, 'tok_devis_003ghi',   '192.168.1.12', 'Mozilla/5.0 (Windows NT 10.0)', '2026-10-01 09:00:00', '2026-10-01 21:00:00', NULL),
  (1, 'tok_irzal_004jkl',   '192.168.1.10', 'Mozilla/5.0 (iPhone)',          '2026-11-01 07:45:00', '2026-11-01 19:45:00', '2026-11-01 12:00:00'),
  (4, 'tok_gabriel_005mno', '192.168.1.13', 'Mozilla/5.0 (Windows NT 10.0)', '2026-11-10 08:30:00', '2026-11-10 20:30:00', NULL);

-- Log aktivitas
INSERT INTO log_aktivitas (id_anggota, aksi, tabel_target, id_target, keterangan) VALUES
  (1, 'CREATE', 'kegiatan',           1, 'Menambah kegiatan Seminar Teknologi AI 2026'),
  (1, 'CREATE', 'kegiatan',           2, 'Menambah kegiatan Rapat Koordinasi Bulanan'),
  (2, 'CREATE', 'draft_surat',        1, 'Membuat draft surat Seminar AI'),
  (2, 'CREATE', 'pengajuan_surat',    1, 'Mengajukan surat Seminar AI'),
  (1, 'UPDATE', 'pengajuan_surat',    1, 'Mengubah status menjadi Diproses'),
  (1, 'UPDATE', 'pengajuan_surat',    1, 'Mengubah status menjadi Selesai'),
  (4, 'CREATE', 'pemasukan',          1, 'Mencatat pemasukan iuran September 2026'),
  (4, 'CREATE', 'pengeluaran',        1, 'Mencatat pengeluaran konsumsi Seminar AI'),
  (4, 'UPDATE', 'pengeluaran',        3, 'Mengubah status pengeluaran transport menjadi Ditolak'),
  (1, 'CREATE', 'kegiatan',           3, 'Menambah kegiatan LKTI 2026'),
  (3, 'CREATE', 'peminjaman_ruangan', 1, 'Mengajukan peminjaman ruang Rapat BPH'),
  (1, 'UPDATE', 'peminjaman_ruangan', 1, 'Menyetujui peminjaman Rapat BPH'),
  (1, 'UPDATE', 'peminjaman_ruangan', 4, 'Menolak peminjaman Rapat Keuangan'),
  (6, 'CREATE', 'pemasukan',          5, 'Mencatat dana DIPA untuk LKTI 2026'),
  (6, 'DELETE', 'pengeluaran',        3, 'Menghapus pengeluaran transport yang ditolak');


-- ============================================================
-- VIEW
-- ============================================================

-- v_anggota_lengkap: jabatan aktif dari periode terbaru
CREATE OR REPLACE VIEW v_anggota_lengkap AS
SELECT
  a.id_anggota,
  a.nim,
  a.nama_lengkap,
  a.email,
  a.no_telp,
  a.angkatan,
  a.jurusan,
  a.program_studi,
  a.status_keanggotaan,
  j.nama_jabatan,
  d.nama_divisi,
  k.kelurahan,
  k.kecamatan,
  k.kota_kabupaten,
  k.provinsi
FROM anggota a
  JOIN anggota_periode ap ON a.id_anggota  = ap.id_anggota
  JOIN periode         p  ON ap.id_periode = p.id_periode
  JOIN jabatan         j  ON ap.id_jabatan = j.id_jabatan
  LEFT JOIN divisi     d  ON j.id_divisi   = d.id_divisi
  JOIN kode_pos        k  ON a.kode_pos    = k.kode_pos
WHERE p.tahun_selesai = (SELECT MAX(tahun_selesai) FROM periode);

CREATE OR REPLACE VIEW v_anggota_per_periode AS
SELECT
  p.tahun_mulai,
  p.tahun_selesai,
  a.nim,
  a.nama_lengkap,
  j.nama_jabatan,
  d.nama_divisi
FROM anggota_periode ap
  JOIN anggota a ON ap.id_anggota = a.id_anggota
  JOIN periode p  ON ap.id_periode = p.id_periode
  JOIN jabatan j  ON ap.id_jabatan = j.id_jabatan
  LEFT JOIN divisi d ON j.id_divisi = d.id_divisi
ORDER BY p.tahun_mulai, j.id_jabatan;

-- ============================================================
-- v_login — PERBAIKAN: tambah kolom email agar Auth.php bisa
--           login dengan username ATAU email.
--
-- ANALISIS MASALAH LOGIN:
--   Versi lama v_login TIDAK memiliki kolom email.
--   Jika Auth.php melakukan:
--     SELECT * FROM v_login WHERE username = '$input'
--   → login via email TIDAK AKAN BERHASIL karena kolom email
--     tidak ada di view, sehingga kondisi WHERE tidak match.
--
--   SOLUSI yang diterapkan di sini:
--     Tambah kolom a.email ke dalam SELECT v_login.
--     Auth.php kemudian bisa query:
--       WHERE username = '$input' OR email = '$input'
--     sehingga mendukung login via username maupun email.
--
--   CONTOH query Auth.php yang direkomendasikan:
--     SELECT * FROM v_login
--     WHERE username = :input OR email = :input
--     LIMIT 1;
-- ============================================================
CREATE OR REPLACE VIEW v_login AS
SELECT
  pw.id_password,
  pw.id_anggota,
  pw.username,
  pw.`password`,
  a.nama_lengkap,
  a.email,                   -- ← DITAMBAHKAN: supaya Auth.php bisa login via email
  j.nama_jabatan,
  d.nama_divisi,
  j.role_level AS role_derived
FROM `password` pw
  JOIN anggota         a  ON pw.id_anggota  = a.id_anggota
  JOIN anggota_periode ap ON a.id_anggota   = ap.id_anggota
  JOIN periode         p  ON ap.id_periode  = p.id_periode
  JOIN jabatan         j  ON ap.id_jabatan  = j.id_jabatan
  LEFT JOIN divisi     d  ON j.id_divisi    = d.id_divisi
WHERE p.tahun_selesai = (SELECT MAX(tahun_selesai) FROM periode);

CREATE OR REPLACE VIEW v_saldo_kas AS
SELECT
  (SELECT COALESCE(SUM(jumlah), 0) FROM pemasukan  WHERE status IN ('Berhasil','Disetujui')) AS total_pemasukan,
  (SELECT COALESCE(SUM(jumlah), 0) FROM pengeluaran WHERE status IN ('Berhasil','Disetujui')) AS total_pengeluaran,
  (SELECT COALESCE(SUM(jumlah), 0) FROM pemasukan  WHERE status IN ('Berhasil','Disetujui')) -
  (SELECT COALESCE(SUM(jumlah), 0) FROM pengeluaran WHERE status IN ('Berhasil','Disetujui')) AS saldo;

CREATE OR REPLACE VIEW v_jadwal_peminjaman AS
SELECT
  dp.id_detail,
  r.kode_ruangan,
  r.nama_ruangan,
  a.nama_lengkap AS nama_peminjam,
  a.nim,
  pr.tujuan_peminjaman,
  pr.status,
  dp.waktu_mulai,
  dp.waktu_selesai
FROM detail_peminjaman dp
  JOIN ruangan            r  ON dp.id_ruangan    = r.id_ruangan
  JOIN peminjaman_ruangan pr ON dp.id_peminjaman = pr.id_peminjaman
  JOIN peminjam           pj ON pr.id_peminjam   = pj.id_peminjam
  JOIN anggota            a  ON pj.id_anggota    = a.id_anggota
ORDER BY dp.waktu_mulai;

CREATE OR REPLACE VIEW v_pengajuan_surat_lengkap AS
SELECT
  ps.id_pengajuan,
  ps.tanggal_unggah,
  ps.tanggal_update,
  ps.status,
  s.file             AS file_surat,
  ds.file            AS file_draft,
  ds.deskripsi_kegiatan,
  a.nama_lengkap     AS pembuat,
  a.nim
FROM pengajuan_surat ps
  JOIN surat       s  ON ps.id_surat   = s.id_surat
  JOIN draft_surat ds ON s.id_draft    = ds.id_draft
  JOIN anggota     a  ON ds.id_anggota = a.id_anggota
ORDER BY ps.tanggal_unggah DESC;

CREATE OR REPLACE VIEW v_laporan_keuangan AS
SELECT
  'pemasukan'        AS tipe,
  pm.id_pemasukan    AS id_transaksi,
  pm.kode_pemasukan  AS kode,
  pm.tanggal,
  pm.jumlah,
  pm.status,
  k.nama_kategori,
  kg.judul           AS judul_kegiatan,
  a.nama_lengkap     AS dicatat_oleh
FROM pemasukan pm
  JOIN kategori  k  ON pm.id_kategori = k.id_kategori
  JOIN anggota   a  ON pm.id_anggota  = a.id_anggota
  LEFT JOIN kegiatan kg ON pm.id_kegiatan = kg.id_kegiatan
UNION ALL
SELECT
  'pengeluaran'       AS tipe,
  pk.id_pengeluaran   AS id_transaksi,
  pk.kode_pengeluaran AS kode,
  pk.tanggal,
  pk.jumlah,
  pk.status,
  k.nama_kategori,
  kg.judul            AS judul_kegiatan,
  a.nama_lengkap      AS dicatat_oleh
FROM pengeluaran pk
  JOIN kategori  k  ON pk.id_kategori = k.id_kategori
  JOIN anggota   a  ON pk.id_anggota  = a.id_anggota
  LEFT JOIN kegiatan kg ON pk.id_kegiatan = kg.id_kegiatan
ORDER BY tanggal DESC;


-- ============================================================
-- RINGKASAN AKUN LOGIN (password plaintext: password123)
-- ============================================================
-- username          | email                  | role_derived | nama
-- irzal.ketua       | irzal@polje.ac.id      | ketua        | Irzal Amru Alqahtani
-- fajar.sekret      | fajar@polje.ac.id      | sekretaris   | Fajar Muharram
-- devis.sekret      | devis@polje.ac.id      | sekretaris   | Devis Sapta Pratama
-- gabriel.bendah    | gabriel@polje.ac.id    | bendahara    | Gabriel Putra S.H
-- aditya.wakil      | aditya@polje.ac.id     | ketua        | Aditya Bambang Kurniawan
-- nanda.bendah      | nanda@polje.ac.id      | bendahara    | M. Nanda Krisna Murti
-- ============================================================
